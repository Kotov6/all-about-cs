/**
 * Created by Kotov_250715 on 11-Jan-16.
 */
class GuessGame {

    private final Player p1 = new Player();
    private final Player p2 = new Player();
    private final Player p3 = new Player();

    public void startGame() {

        boolean p1isRight = false;
        boolean p2isRight = false;
        boolean p3isRight = false;

        p1.gender();
        p2.gender();
        p3.gender();

        while (true) {

            int targetNumber = (int) (Math.random() * 10);
            System.out.println("Число, которое нужно угадать,  " + targetNumber);

            p1.guess();
            p2.guess();
            p3.guess();

            System.out.println(p1.name + " думает, что это " + p1.number);
            System.out.println(p2.name + " думает, что это " + p2.number);
            System.out.println(p3.name + " думает, что это " + p3.number);

            if (p1.number == targetNumber) {
                p1isRight = true;
            }
            if (p2.number == targetNumber) {
                p2isRight = true;
            }
            if (p3.number == targetNumber) {
                p3isRight = true;
            }

            if ((p1isRight && (p1.sex == 1)) || (p2isRight && (p2.sex == 1)) || (p3isRight && (p3.sex == 1))) {

                System.out.println("У нас есть победитель!");
                System.out.println("Джентельмены всегда выигрывают!)");
                System.out.println("Конец игры.");
                break;

            } else if ((p1isRight && (p1.sex == 0)) || (p2isRight && (p2.sex == 0)) || (p3isRight && (p3.sex == 0))) {

                System.out.println("У нас есть победитель!");
                System.out.println("Леди иногда бывают правы !)");
                System.out.println("Конец игры.");
                break;

            } else {

                System.out.println("Игроки должны попробовать еще раз.");
                System.out.println("");
            }
        }
    }
}
