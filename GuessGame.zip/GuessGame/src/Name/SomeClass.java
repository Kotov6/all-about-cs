package Name;

/**
 * Created by Kotov_250715 on 19-Feb-16.
 */
public class SomeClass {

    public static void main(String args[]) {
        SomeClass2 s = new SomeClass2();
    }

    public SomeClass() {
        System.out.print("1");
    }

    {
        System.out.print("2");
    }
}

class SomeClass2 extends SomeClass {
    public SomeClass2() {
        System.out.print("3");
    }

    {
        System.out.print("4");
    }
}

