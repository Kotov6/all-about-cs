/**
 * Created by Igor Batiy on 11-Jan-16.
 */

class GameLauncher {
    public static void main(String[] args) {
        GuessGame game = new GuessGame();
        game.startGame();
    }
}
