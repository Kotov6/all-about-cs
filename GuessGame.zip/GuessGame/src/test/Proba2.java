package test;

/**
 * Created by Kotov_250715 on 30-Jan-16.
 */
public class Proba2 {

    static int cnt = 0; // статическое поле
    int a = 10;         // обычное поле


    public void print() {
        System.out.println("cnt=" + cnt);
        System.out.println("a=" + a);
    }

    public static void main(String args[]) {
        Proba2 obj1 = new Proba2();
        cnt++;          // увеличим cnt на 1
        obj1.print();
        Proba2 obj2 = new Proba2();
        cnt++;          // увеличим cnt на 1
        obj2.a = 0;
        //obj1.print();
        obj2.print();
        obj1.print();
    }

}