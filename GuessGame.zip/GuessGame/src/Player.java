/**
 * Created by Igor Batiy on 11-Jan-16.
 */

class Player {
    String name;
    int sex = 0;
    int number = 0;

    public void guess() {
        number = (int) (Math.random() * 10);
    }

    public void gender() {
        sex = (int) (Math.random() * 2);
        if (sex == 0) {
            name = "Леди";
        }
        if (sex == 1) {
            name = "Джентельмен";
        }
    }
}
